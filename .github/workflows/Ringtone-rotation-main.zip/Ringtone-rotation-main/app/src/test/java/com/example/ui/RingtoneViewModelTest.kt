package com.example.ui

import androidx.test.core.app.ApplicationProvider
import androidx.work.testing.WorkManagerTestInitHelper
import com.example.RingtoneRotatorApplication
import com.example.data.model.MediaStoreAudioItem
import com.example.data.model.RingtoneSource
import com.example.data.model.ScheduleInterval
import com.example.data.model.SoundType
import com.example.work.RingtoneWorkScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], application = RingtoneRotatorApplication::class)
class RingtoneViewModelTest {

    private val testDispatcher = StandardTestDispatcher()
    private lateinit var app: RingtoneRotatorApplication
    private lateinit var viewModel: RingtoneViewModel

    @Before
    fun setUp() {
        Dispatchers.setMain(testDispatcher)
        app = ApplicationProvider.getApplicationContext()
        WorkManagerTestInitHelper.initializeTestWorkManager(app)
        viewModel = RingtoneViewModel(app)
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Test
    fun testViewModelStateInitialization() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        assertNotNull(viewModel.availableRingtones)
        assertNotNull(viewModel.currentRotationIndex)
        assertNotNull(viewModel.mediaStoreAudioItems)
        assertNotNull(viewModel.hasPermission)
        assertNotNull(viewModel.hasStoragePermission)

        // Rotation index initial check
        val initialIndex = viewModel.currentRotationIndex.value
        assertEquals(0, initialIndex)
    }

    @Test
    fun testSetRotationIndex() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        viewModel.setRotationIndex(3)
        assertEquals(3, viewModel.currentRotationIndex.value)
        assertEquals(3, viewModel.currentIndex.value)
    }

    @Test
    fun testSoundTypeSelection() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        viewModel.setSoundType(SoundType.NOTIFICATION)
        assertEquals(SoundType.NOTIFICATION, viewModel.soundType.value)
    }

    @Test
    fun testAddMediaStoreAudioToPlaylist() = runBlocking {
        val sampleItem = MediaStoreAudioItem(
            id = 999L,
            title = "Test Sound",
            artist = "Studio",
            album = "Effects",
            durationMs = 8000L,
            sizeBytes = 256000L,
            uri = android.net.Uri.parse("content://media/external/audio/media/999"),
            isRingtone = true,
            isNotification = false,
            isAlarm = false,
            isMusic = false
        )

        val ringtone = sampleItem.toRingtoneItem(SoundType.RINGTONE)
        app.repository.addRingtone(ringtone)

        val allItems = app.repository.allRingtones.first()
        val added = allItems.find { it.uriString == sampleItem.uri.toString() }
        assertNotNull(added)
        assertEquals(RingtoneSource.MEDIASTORE, added?.source)
    }

    @Test
    fun testRotateNowInvokesLogicAndProvidesFeedback() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        // Verify initial state
        assertEquals(false, viewModel.isRotating.value)

        // Invoke rotateNow
        viewModel.rotateNow()
        testDispatcher.scheduler.advanceUntilIdle()

        // Either it is actively rotating on IO or completed with status/feedback
        val isRotating = viewModel.isRotating.value
        val feedback = viewModel.rotationFeedback.value
        val status = viewModel.statusMessage.value
        assertTrue(isRotating || feedback != null || status != null)

        // Verify clear feedback works
        viewModel.clearRotationFeedback()
        assertEquals(null, viewModel.rotationFeedback.value)
    }

    @Test
    fun testWorkManagerScheduleConfiguration() = runTest {
        testDispatcher.scheduler.advanceUntilIdle()

        viewModel.setScheduleInterval(ScheduleInterval.DAILY)
        assertEquals(ScheduleInterval.DAILY, viewModel.scheduleInterval.value)

        // Verify WorkManager scheduler enqueues the periodic work without exception
        RingtoneWorkScheduler.scheduleRotation(app, ScheduleInterval.DAILY)

        // Also test immediate rotation work trigger
        viewModel.triggerBackgroundRotationWork()
    }
}
