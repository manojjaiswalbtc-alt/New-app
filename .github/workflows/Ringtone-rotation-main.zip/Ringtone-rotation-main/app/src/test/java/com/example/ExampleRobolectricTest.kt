package com.example

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.example.core.RingtoneRotator
import com.example.core.RuntimePermissionsHelper
import com.example.data.dao.MediaStoreAudioDaoImpl
import com.example.data.model.MediaStoreAudioItem
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource
import com.example.data.model.RotationMode
import com.example.data.model.SoundType
import com.example.data.repository.MediaStoreAudioRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Ringtone Rotator", appName)
    }

    @Test
    fun `test rotator initialization and empty list safety`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val rotator = RingtoneRotator(context)
        assertNotNull(rotator)

        val result = rotator.rotate(
            ringtoneItems = emptyList(),
            currentIndex = 0,
            mode = RotationMode.SEQUENTIAL,
            soundType = SoundType.RINGTONE
        )
        // With empty items, rotator handles it safely without crashing
        assertEquals(false, result.success)
    }

    @Test
    fun `test media store dao and repository initialization and scanning`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val dao = MediaStoreAudioDaoImpl(context.contentResolver)
        assertNotNull(dao)

        val repository = MediaStoreAudioRepository(context, dao)
        assertNotNull(repository)

        // Verify required permission name
        val requiredPermission = repository.getRequiredStoragePermission()
        assertTrue(requiredPermission.contains("READ_MEDIA_AUDIO") || requiredPermission.contains("READ_EXTERNAL_STORAGE"))

        // Run scan on repository
        val results = repository.scanAudioFiles(filterType = SoundType.RINGTONE)
        assertNotNull(results)
    }

    @Test
    fun `test media store item to ringtone item conversion`() {
        val testUri = Uri.parse("content://media/external/audio/media/42")
        val mediaItem = MediaStoreAudioItem(
            id = 42L,
            title = "Morning Alarm",
            artist = "Acoustic Band",
            album = "Sunrise Album",
            durationMs = 15000L,
            sizeBytes = 1024000L,
            uri = testUri,
            isRingtone = true,
            isNotification = false,
            isAlarm = true,
            isMusic = false
        )

        val ringtoneItem = mediaItem.toRingtoneItem(SoundType.RINGTONE)
        assertEquals("Morning Alarm - Acoustic Band", ringtoneItem.title)
        assertEquals(testUri.toString(), ringtoneItem.uriString)
        assertEquals(RingtoneSource.MEDIASTORE, ringtoneItem.source)
        assertEquals(SoundType.RINGTONE, ringtoneItem.soundType)
        assertEquals(15000L, ringtoneItem.durationMs)
        assertTrue(ringtoneItem.isEnabledInPlaylist)
    }

    @Test
    fun `test runtime permissions helper api check`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audioPermission = RuntimePermissionsHelper.getAudioPermission()
        // On SDK 34 (Android 14), it should return READ_MEDIA_AUDIO
        assertEquals(android.Manifest.permission.READ_MEDIA_AUDIO, audioPermission)

        // hasAudioPermission should return a boolean without crashing
        val hasPermission = RuntimePermissionsHelper.hasAudioPermission(context)
        assertNotNull(hasPermission)

        // hasWriteSettingsPermission should return a boolean without crashing
        val hasWriteSettings = RuntimePermissionsHelper.hasWriteSettingsPermission(context)
        assertNotNull(hasWriteSettings)
    }
}
