package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.RotationHistoryItem
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM rotation_history ORDER BY timestamp DESC LIMIT 100")
    fun getRecentHistory(): Flow<List<RotationHistoryItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(historyItem: RotationHistoryItem): Long

    @Query("DELETE FROM rotation_history")
    suspend fun clearAll()
}
