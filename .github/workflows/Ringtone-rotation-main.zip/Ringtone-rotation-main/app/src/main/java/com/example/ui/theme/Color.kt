package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ringtone Rotator Color Palette
val PrimaryIndigo = Color(0xFF6366F1)
val PrimaryIndigoDark = Color(0xFF818CF8)
val PrimaryIndigoContainer = Color(0xFF312E81)
val PrimaryIndigoContainerLight = Color(0xFFE0E7FF)

val CyanAccent = Color(0xFF06B6D4)
val CyanAccentDark = Color(0xFF22D3EE)
val CyanAccentContainer = Color(0xFF164E63)
val CyanAccentContainerLight = Color(0xFFCFFAFE)

val AmberVibrant = Color(0xFFF59E0B)
val AmberVibrantDark = Color(0xFFFBBF24)
val AmberVibrantContainer = Color(0xFF78350F)
val AmberVibrantContainerLight = Color(0xFFFEF3C7)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
val DarkSurfaceHigh = Color(0xFF243248)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightSurfaceHigh = Color(0xFFE2E8F0)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
