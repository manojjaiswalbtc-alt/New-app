package com.example.data.model

import android.net.Uri

data class MediaStoreAudioItem(
    val id: Long,
    val title: String,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val sizeBytes: Long,
    val uri: Uri,
    val isRingtone: Boolean,
    val isNotification: Boolean,
    val isAlarm: Boolean,
    val isMusic: Boolean
) {
    fun toRingtoneItem(soundType: SoundType = SoundType.RINGTONE): RingtoneItem {
        return RingtoneItem(
            title = if (!artist.isNullOrBlank() && artist != "<unknown>") "$title - $artist" else title,
            uriString = uri.toString(),
            source = RingtoneSource.MEDIASTORE,
            soundType = soundType,
            durationMs = durationMs,
            isEnabledInPlaylist = true
        )
    }
}
