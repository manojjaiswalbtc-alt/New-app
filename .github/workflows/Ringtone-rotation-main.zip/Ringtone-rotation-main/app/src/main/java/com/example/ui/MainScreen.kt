package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.PermissionStatusBadge
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.PlaylistScreen
import com.example.ui.screens.RotateScreen
import com.example.ui.screens.ScheduleScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: RingtoneViewModel,
    modifier: Modifier = Modifier
) {
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val hasPermission by viewModel.hasPermission.collectAsStateWithLifecycle()
    val hasStoragePermission by viewModel.hasStoragePermission.collectAsStateWithLifecycle()
    val mediaStoreAudioItems by viewModel.mediaStoreAudioItems.collectAsStateWithLifecycle()
    val isScanningMediaStore by viewModel.isScanningMediaStore.collectAsStateWithLifecycle()
    val currentSystemTitle by viewModel.currentSystemTitle.collectAsStateWithLifecycle()
    val currentSystemUri by viewModel.currentSystemUri.collectAsStateWithLifecycle()
    val soundType by viewModel.soundType.collectAsStateWithLifecycle()
    val rotationMode by viewModel.rotationMode.collectAsStateWithLifecycle()
    val scheduleInterval by viewModel.scheduleInterval.collectAsStateWithLifecycle()
    val notificationsEnabled by viewModel.notificationsEnabled.collectAsStateWithLifecycle()
    val currentIndex by viewModel.currentIndex.collectAsStateWithLifecycle()
    val playlistItems by viewModel.playlistItems.collectAsStateWithLifecycle()
    val enabledItems by viewModel.enabledPlaylistItems.collectAsStateWithLifecycle()
    val systemTones by viewModel.systemLibraryTones.collectAsStateWithLifecycle()
    val isLoadingLibrary by viewModel.isLoadingLibrary.collectAsStateWithLifecycle()
    val recentHistory by viewModel.recentHistory.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val isRotating by viewModel.isRotating.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val rotationFeedback by viewModel.rotationFeedback.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val lifecycleOwner = LocalLifecycleOwner.current

    // Re-check permissions and reload current system sound whenever user returns from Settings app
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermission()
                viewModel.refreshStoragePermission()
                viewModel.refreshCurrentSystemRingtone()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Show status messages in snackbar
    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    // BackHandler to navigate back to Rotate dashboard from other tabs
    BackHandler(enabled = selectedTab != NavigationTab.ROTATE) {
        viewModel.setSelectedTab(NavigationTab.ROTATE)
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ringtone Rotator",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.rotateNow() },
                        enabled = !isRotating,
                        modifier = Modifier.testTag("top_app_bar_rotate_button")
                    ) {
                        if (isRotating) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Autorenew,
                                contentDescription = "Rotate Ringtone Now",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    PermissionStatusBadge(
                        hasPermission = hasPermission,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.ROTATE,
                    onClick = { viewModel.setSelectedTab(NavigationTab.ROTATE) },
                    icon = { Icon(Icons.Default.Autorenew, contentDescription = "Rotate") },
                    label = { Text("Rotate") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_rotate")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.PLAYLIST,
                    onClick = { viewModel.setSelectedTab(NavigationTab.PLAYLIST) },
                    icon = { Icon(Icons.AutoMirrored.Default.QueueMusic, contentDescription = "Playlist") },
                    label = { Text("Playlist") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_playlist")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.LIBRARY,
                    onClick = { viewModel.setSelectedTab(NavigationTab.LIBRARY) },
                    icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
                    label = { Text("Library") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_library")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.SCHEDULE,
                    onClick = { viewModel.setSelectedTab(NavigationTab.SCHEDULE) },
                    icon = { Icon(Icons.Default.Schedule, contentDescription = "Schedule") },
                    label = { Text("Schedule") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_schedule")
                )
                NavigationBarItem(
                    selected = selectedTab == NavigationTab.HISTORY,
                    onClick = { viewModel.setSelectedTab(NavigationTab.HISTORY) },
                    icon = { Icon(Icons.Default.History, contentDescription = "History") },
                    label = { Text("History") },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("nav_tab_history")
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_animation"
            ) { targetTab ->
                when (targetTab) {
                    NavigationTab.ROTATE -> {
                        RotateScreen(
                            hasPermission = hasPermission,
                            onRequestPermission = { viewModel.requestPermission() },
                            soundType = soundType,
                            onSoundTypeChange = { viewModel.setSoundType(it) },
                            rotationMode = rotationMode,
                            onRotationModeChange = { viewModel.setRotationMode(it) },
                            currentSystemTitle = currentSystemTitle,
                            currentSystemUri = currentSystemUri,
                            playbackState = playbackState,
                            onTogglePlaySystem = { currentSystemUri?.let { viewModel.togglePreview(it) } },
                            playlistItems = enabledItems,
                            currentIndex = currentIndex,
                            isRotating = isRotating,
                            onRotateNow = { viewModel.rotateNow() },
                            scheduleInterval = scheduleInterval,
                            historyCount = recentHistory.size,
                            onNavigateToPlaylist = { viewModel.setSelectedTab(NavigationTab.PLAYLIST) },
                            onNavigateToSchedule = { viewModel.setSelectedTab(NavigationTab.SCHEDULE) },
                            rotationFeedback = rotationFeedback,
                            onDismissFeedback = { viewModel.clearRotationFeedback() }
                        )
                    }

                    NavigationTab.PLAYLIST -> {
                        PlaylistScreen(
                            playlistItems = playlistItems,
                            playbackState = playbackState,
                            currentSystemTitle = currentSystemTitle,
                            onTogglePlay = { viewModel.togglePreview(it) },
                            onTogglePlaylist = { viewModel.togglePlaylistEnabled(it) },
                            onApplyNow = { viewModel.applySpecificRingtone(it) },
                            onDelete = { viewModel.deleteItem(it) },
                            onNavigateToLibrary = { viewModel.setSelectedTab(NavigationTab.LIBRARY) },
                            onRotateNow = { viewModel.rotateNow() },
                            isRotating = isRotating,
                            rotationFeedback = rotationFeedback,
                            onDismissFeedback = { viewModel.clearRotationFeedback() }
                        )
                    }

                    NavigationTab.LIBRARY -> {
                        LibraryScreen(
                            systemTones = systemTones,
                            playlistItems = playlistItems,
                            mediaStoreItems = mediaStoreAudioItems,
                            isScanningMediaStore = isScanningMediaStore,
                            hasStoragePermission = hasStoragePermission,
                            requiredStoragePermission = viewModel.getRequiredStoragePermission(),
                            onStoragePermissionResult = { isGranted ->
                                viewModel.refreshStoragePermission()
                            },
                            onScanMediaStore = { viewModel.scanMediaStoreAudio() },
                            isLoading = isLoadingLibrary,
                            playbackState = playbackState,
                            soundType = soundType,
                            onTogglePlay = { viewModel.togglePreview(it) },
                            onAddToPlaylist = { viewModel.addLibraryToneToPlaylist(it) },
                            onAddMediaStoreToPlaylist = { viewModel.addMediaStoreAudioToPlaylist(it) },
                            onApplyNow = { viewModel.applySpecificRingtone(it) },
                            onApplyMediaStoreNow = { viewModel.applyMediaStoreAudioNow(it) },
                            onImportAudio = { viewModel.importCustomAudio(it) },
                            onRefreshSystemTones = { viewModel.loadSystemRingtones() }
                        )
                    }

                    NavigationTab.SCHEDULE -> {
                        ScheduleScreen(
                            currentInterval = scheduleInterval,
                            onIntervalChange = { viewModel.setScheduleInterval(it) },
                            notificationsEnabled = notificationsEnabled,
                            onNotificationsChange = { viewModel.setNotificationsEnabled(it) },
                            onTriggerTestRotation = { viewModel.rotateNow() }
                        )
                    }

                    NavigationTab.HISTORY -> {
                        HistoryScreen(
                            historyItems = recentHistory,
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }
                }
            }
        }
    }
}
