package com.example.work

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.MainActivity
import com.example.R
import com.example.RingtoneRotatorApplication
import com.example.core.RuntimePermissionsHelper
import com.example.data.model.RotationHistoryItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * WorkManager worker that runs background tasks to cycle the RingtoneRotator
 * to the next ringtone at user-defined intervals (e.g. daily, 12 hours, etc.).
 */
class RingtoneRotationWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        const val TAG = "RingtoneRotationWorker"
        const val WORK_NAME_PERIODIC = "ringtone_rotation_periodic_work"
        const val WORK_NAME_ONE_TIME = "ringtone_rotation_one_time_work"
        private const val NOTIFICATION_ID = 5002
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Executing scheduled ringtone rotation background task")

        if (!RuntimePermissionsHelper.hasWriteSettingsPermission(applicationContext)) {
            Log.w(TAG, "Cannot rotate ringtone: WRITE_SETTINGS permission not granted")
            return@withContext Result.failure()
        }

        val app = applicationContext as? RingtoneRotatorApplication ?: run {
            Log.e(TAG, "Application is not RingtoneRotatorApplication")
            return@withContext Result.failure()
        }

        try {
            val soundType = app.preferenceStorage.soundType.value
            val mode = app.preferenceStorage.rotationMode.value
            val currentIndex = app.preferenceStorage.currentIndex.value

            val playlist = app.repository.getEnabledBySoundType(soundType)
            if (playlist.isEmpty()) {
                Log.d(TAG, "Playlist is empty for ${soundType.title}, skipping rotation")
                return@withContext Result.success()
            }

            val result = app.rotator.rotate(
                ringtoneItems = playlist,
                currentIndex = currentIndex,
                mode = mode,
                soundType = soundType
            )

            if (result.success && result.rotatedItem != null) {
                app.preferenceStorage.setCurrentIndex(result.nextIndex)
                app.preferenceStorage.recordRotation(result.rotatedItem.title)

                app.repository.recordHistory(
                    RotationHistoryItem(
                        ringtoneTitle = result.rotatedItem.title,
                        ringtoneUri = result.rotatedItem.uriString,
                        soundType = soundType.title,
                        triggerSource = "WorkManager",
                        isSuccessful = true
                    )
                )

                if (app.preferenceStorage.notificationsEnabled.value) {
                    sendRotationNotification(
                        toneTitle = result.rotatedItem.title,
                        typeTitle = soundType.title
                    )
                }

                Log.d(TAG, "Successfully cycled to next ringtone: ${result.rotatedItem.title}")
                Result.success()
            } else {
                Log.w(TAG, "Ringtone rotation returned failure: ${result.message}")
                app.repository.recordHistory(
                    RotationHistoryItem(
                        ringtoneTitle = result.rotatedItem?.title ?: "Unknown",
                        ringtoneUri = result.rotatedItem?.uriString ?: "",
                        soundType = soundType.title,
                        triggerSource = "WorkManager",
                        isSuccessful = false,
                        errorMessage = result.message
                    )
                )
                Result.retry()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unexpected error in RingtoneRotationWorker", e)
            Result.retry()
        }
    }

    private fun sendRotationNotification(toneTitle: String, typeTitle: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val launchIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val contentIntent = PendingIntent.getActivity(applicationContext, 0, launchIntent, flags)

        val notification = NotificationCompat.Builder(applicationContext, RingtoneRotatorApplication.CHANNEL_ID_ROTATION)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Ringtone Auto-Rotated")
            .setContentText("Active $typeTitle sound: $toneTitle")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("WorkManager scheduled task automatically cycled your $typeTitle to '$toneTitle'.")
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            Log.w(TAG, "Notification permission missing", e)
        }
    }
}
