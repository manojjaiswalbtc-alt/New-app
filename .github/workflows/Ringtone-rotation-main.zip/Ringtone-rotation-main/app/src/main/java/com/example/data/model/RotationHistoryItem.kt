package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "rotation_history")
data class RotationHistoryItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ringtoneTitle: String,
    val ringtoneUri: String,
    val soundType: String,
    val triggerSource: String, // "Manual", "Schedule", "Test"
    val timestamp: Long = System.currentTimeMillis(),
    val isSuccessful: Boolean = true,
    val errorMessage: String? = null
)
