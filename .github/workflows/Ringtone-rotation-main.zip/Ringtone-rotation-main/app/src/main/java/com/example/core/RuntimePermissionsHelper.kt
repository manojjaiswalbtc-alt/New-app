package com.example.core

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Helper class to centralize runtime permission checking and rationale
 * logic for audio files across Android versions (API 33+ READ_MEDIA_AUDIO vs
 * older READ_EXTERNAL_STORAGE) and system write settings.
 */
object RuntimePermissionsHelper {

    /**
     * Returns the required permission for reading audio files based on the OS level:
     * - Android 13+ (API 33+ / TIRAMISU): Manifest.permission.READ_MEDIA_AUDIO
     * - Android 12 and below: Manifest.permission.READ_EXTERNAL_STORAGE
     */
    fun getAudioPermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    /**
     * Checks whether the application has been granted permission to read device audio files.
     */
    fun hasAudioPermission(context: Context): Boolean {
        val permission = getAudioPermission()
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Checks if rationale should be shown before requesting audio permissions.
     */
    fun shouldShowAudioPermissionRationale(activity: Activity): Boolean {
        return ActivityCompat.shouldShowRequestPermissionRationale(activity, getAudioPermission())
    }

    /**
     * Checks if the app has permission to write system settings (for changing ringtone).
     */
    fun hasWriteSettingsPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.System.canWrite(context)
        } else {
            true
        }
    }

    /**
     * Launches the system settings screen for toggling WRITE_SETTINGS.
     */
    fun openWriteSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallbackIntent)
            }
        }
    }

    /**
     * Opens the app's detailed system settings screen in case permissions are permanently denied.
     */
    fun openAppSettings(context: Context) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
