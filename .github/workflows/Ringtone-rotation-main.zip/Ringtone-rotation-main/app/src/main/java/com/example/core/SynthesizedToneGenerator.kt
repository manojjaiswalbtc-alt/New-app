package com.example.core

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource
import com.example.data.model.SoundType
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

object SynthesizedToneGenerator {

    data class ToneSpec(
        val filename: String,
        val title: String,
        val frequencies: List<Double>,
        val durationSeconds: Double,
        val decaySpeed: Double
    )

    private val PRESETS = listOf(
        ToneSpec(
            filename = "cosmic_pulse.wav",
            title = "Cosmic Pulse",
            frequencies = listOf(440.0, 554.37, 659.25, 880.0), // A major chord
            durationSeconds = 2.8,
            decaySpeed = 1.2
        ),
        ToneSpec(
            filename = "zen_marimba.wav",
            title = "Zen Marimba",
            frequencies = listOf(523.25, 659.25, 783.99, 1046.50), // C major arpeggio
            durationSeconds = 2.5,
            decaySpeed = 2.0
        ),
        ToneSpec(
            filename = "cyber_chime.wav",
            title = "Cyber Chime",
            frequencies = listOf(587.33, 739.99, 880.0, 1174.66), // D major high sparkle
            durationSeconds = 2.2,
            decaySpeed = 1.6
        ),
        ToneSpec(
            filename = "golden_sunrise.wav",
            title = "Golden Sunrise",
            frequencies = listOf(392.0, 493.88, 587.33, 783.99), // G major morning bell
            durationSeconds = 3.0,
            decaySpeed = 1.0
        )
    )

    fun ensurePresetTones(context: Context): List<RingtoneItem> {
        val toneDir = File(context.filesDir, "preset_ringtones").apply { mkdirs() }
        val items = mutableListOf<RingtoneItem>()

        PRESETS.forEachIndexed { index, spec ->
            val file = File(toneDir, spec.filename)
            if (!file.exists() || file.length() < 100L) {
                generateWavFile(file, spec)
            }
            val uri = Uri.fromFile(file)
            items.add(
                RingtoneItem(
                    title = spec.title,
                    uriString = uri.toString(),
                    source = RingtoneSource.PRESET,
                    soundType = SoundType.RINGTONE,
                    durationMs = (spec.durationSeconds * 1000).toLong(),
                    isEnabledInPlaylist = true,
                    orderIndex = index
                )
            )
        }
        return items
    }

    private fun generateWavFile(targetFile: File, spec: ToneSpec) {
        val sampleRate = 44100
        val totalSamples = (sampleRate * spec.durationSeconds).toInt()
        val numChannels = 1
        val bitsPerSample = 16
        val byteRate = sampleRate * numChannels * (bitsPerSample / 8)
        val dataSize = totalSamples * (bitsPerSample / 8)

        FileOutputStream(targetFile).use { fos ->
            // WAV Header
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(36 + dataSize)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1) // AudioFormat 1 = PCM
            header.putShort(numChannels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort((numChannels * (bitsPerSample / 8)).toShort()) // BlockAlign
            header.putShort(bitsPerSample.toShort())
            header.put("data".toByteArray())
            header.putInt(dataSize)

            fos.write(header.array())

            // Synthesize PCM samples
            val pcmBuffer = ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN)
            val noteDuration = spec.durationSeconds / spec.frequencies.size

            for (i in 0 until totalSamples) {
                val t = i.toDouble() / sampleRate
                val noteIndex = (t / noteDuration).toInt().coerceIn(0, spec.frequencies.size - 1)
                val freq = spec.frequencies[noteIndex]
                val noteTime = t - (noteIndex * noteDuration)

                // Exponential decay envelope
                val envelope = exp(-spec.decaySpeed * noteTime)
                // Fundamental + octave overtone harmonic
                val sampleValue = (sin(2.0 * PI * freq * t) * 0.7 + sin(2.0 * PI * freq * 2 * t) * 0.3) * envelope

                val shortSample = (sampleValue * Short.MAX_VALUE * 0.8).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                pcmBuffer.clear()
                pcmBuffer.putShort(shortSample)
                fos.write(pcmBuffer.array())
            }
        }
    }
}
