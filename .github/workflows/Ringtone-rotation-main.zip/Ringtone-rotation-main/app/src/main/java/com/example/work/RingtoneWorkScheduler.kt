package com.example.work

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.model.ScheduleInterval
import java.util.concurrent.TimeUnit

/**
 * Manages WorkManager background task scheduling to trigger RingtoneRotator
 * to cycle to the next ringtone at user-defined intervals (e.g., hourly, every 12 hours, daily).
 */
object RingtoneWorkScheduler {

    private const val TAG = "RingtoneWorkScheduler"

    /**
     * Schedules periodic background rotation according to user-selected interval,
     * or cancels any existing scheduled work if MANUAL is selected.
     */
    fun scheduleRotation(context: Context, interval: ScheduleInterval) {
        val workManager = WorkManager.getInstance(context)

        if (interval == ScheduleInterval.MANUAL) {
            workManager.cancelUniqueWork(RingtoneRotationWorker.WORK_NAME_PERIODIC)
            Log.d(TAG, "Cancelled periodic WorkManager rotation task")
            return
        }

        // WorkManager requires at least 15 minutes repeat interval
        val repeatIntervalMinutes = (interval.intervalMillis / (60 * 1000L)).coerceAtLeast(15L)

        val periodicWorkRequest = PeriodicWorkRequestBuilder<RingtoneRotationWorker>(
            repeatIntervalMinutes,
            TimeUnit.MINUTES
        )
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                15,
                TimeUnit.MINUTES
            )
            .addTag("ringtone_rotation")
            .build()

        workManager.enqueueUniquePeriodicWork(
            RingtoneRotationWorker.WORK_NAME_PERIODIC,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodicWorkRequest
        )

        Log.d(TAG, "Enqueued periodic WorkManager task for interval: ${interval.displayName} ($repeatIntervalMinutes min)")
    }

    /**
     * Triggers an immediate one-time background rotation task using WorkManager.
     */
    fun triggerImmediateRotation(context: Context) {
        val workManager = WorkManager.getInstance(context)
        val oneTimeWorkRequest = OneTimeWorkRequestBuilder<RingtoneRotationWorker>()
            .addTag("ringtone_rotation_manual")
            .build()

        workManager.enqueueUniqueWork(
            RingtoneRotationWorker.WORK_NAME_ONE_TIME,
            ExistingWorkPolicy.REPLACE,
            oneTimeWorkRequest
        )

        Log.d(TAG, "Enqueued immediate one-time WorkManager rotation task")
    }

    /**
     * Cancels all scheduled WorkManager rotation tasks.
     */
    fun cancelAll(context: Context) {
        val workManager = WorkManager.getInstance(context)
        workManager.cancelUniqueWork(RingtoneRotationWorker.WORK_NAME_PERIODIC)
        workManager.cancelUniqueWork(RingtoneRotationWorker.WORK_NAME_ONE_TIME)
        Log.d(TAG, "Cancelled all WorkManager rotation tasks")
    }
}
