package com.example.data.model

import android.media.RingtoneManager

enum class SoundType(val title: String, val ringtoneManagerType: Int) {
    RINGTONE("Phone Call", RingtoneManager.TYPE_RINGTONE),
    NOTIFICATION("Notification", RingtoneManager.TYPE_NOTIFICATION),
    ALARM("Alarm", RingtoneManager.TYPE_ALARM)
}

enum class RotationMode(val displayName: String, val description: String) {
    SEQUENTIAL("Sequential", "Cycles through the playlist in order"),
    SHUFFLE("Shuffle", "Picks a random ringtone from active playlist")
}

enum class ScheduleInterval(val displayName: String, val intervalMillis: Long) {
    MANUAL("Manual Only", 0L),
    HOURLY("Every 1 Hour", 60 * 60 * 1000L),
    EVERY_4_HOURS("Every 4 Hours", 4 * 60 * 60 * 1000L),
    EVERY_12_HOURS("Every 12 Hours", 12 * 60 * 60 * 1000L),
    DAILY("Every 24 Hours", 24 * 60 * 60 * 1000L)
}

enum class RingtoneSource(val label: String) {
    SYSTEM("System"),
    CUSTOM("Custom File"),
    PRESET("Preset Tone"),
    MEDIASTORE("Device Audio")
}
