package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.example.core.SynthesizedToneGenerator
import com.example.data.db.AppDatabase
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource
import com.example.data.model.RotationHistoryItem
import com.example.data.model.SoundType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class RingtoneRepository(
    private val context: Context,
    private val database: AppDatabase
) {
    private val ringtoneDao = database.ringtoneDao()
    private val historyDao = database.historyDao()

    val allRingtones: Flow<List<RingtoneItem>> = ringtoneDao.getAllRingtones()
    val enabledPlaylistRingtones: Flow<List<RingtoneItem>> = ringtoneDao.getEnabledPlaylistRingtones()
    val recentHistory: Flow<List<RotationHistoryItem>> = historyDao.getRecentHistory()

    suspend fun getEnabledPlaylistSnapshot(): List<RingtoneItem> {
        return withContext(Dispatchers.IO) {
            ringtoneDao.getEnabledPlaylistSnapshot()
        }
    }

    suspend fun getEnabledBySoundType(soundType: SoundType): List<RingtoneItem> {
        return withContext(Dispatchers.IO) {
            ringtoneDao.getEnabledBySoundType(soundType)
        }
    }

    suspend fun initializeDefaultsIfEmpty() {
        withContext(Dispatchers.IO) {
            val count = ringtoneDao.getCount()
            if (count == 0) {
                // Generate bundled synthesized tones
                val presets = SynthesizedToneGenerator.ensurePresetTones(context)
                ringtoneDao.insertAll(presets)
            }
        }
    }

    suspend fun addCustomAudio(sourceUri: Uri): Result<RingtoneItem> {
        return withContext(Dispatchers.IO) {
            try {
                val customDir = File(context.filesDir, "custom_ringtones").apply { mkdirs() }
                val fileName = "custom_${System.currentTimeMillis()}.mp3"
                val destFile = File(customDir, fileName)

                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                } ?: return@withContext Result.failure(Exception("Could not read audio stream"))

                val fileUri = Uri.fromFile(destFile)

                // Read title and duration via MediaMetadataRetriever
                var title = "Custom Audio"
                var durationMs = 0L
                try {
                    val mmr = MediaMetadataRetriever()
                    mmr.setDataSource(destFile.absolutePath)
                    title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                        ?: destFile.nameWithoutExtension
                    val durStr = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    durationMs = durStr?.toLongOrNull() ?: 0L
                    mmr.release()
                } catch (e: Exception) {
                    Log.w("RingtoneRepository", "Could not extract metadata", e)
                }

                val item = RingtoneItem(
                    title = title,
                    uriString = fileUri.toString(),
                    source = RingtoneSource.CUSTOM,
                    soundType = SoundType.RINGTONE,
                    durationMs = durationMs,
                    isEnabledInPlaylist = true
                )
                val id = ringtoneDao.insert(item)
                Result.success(item.copy(id = id))
            } catch (e: Exception) {
                Log.e("RingtoneRepository", "Failed to add custom audio", e)
                Result.failure(e)
            }
        }
    }

    suspend fun addRingtone(item: RingtoneItem): Long {
        return withContext(Dispatchers.IO) {
            val existing = ringtoneDao.findByUri(item.uriString)
            if (existing != null) {
                ringtoneDao.setEnabled(existing.id, true)
                existing.id
            } else {
                ringtoneDao.insert(item)
            }
        }
    }

    suspend fun togglePlaylistEnabled(id: Long, enabled: Boolean) {
        withContext(Dispatchers.IO) {
            ringtoneDao.setEnabled(id, enabled)
        }
    }

    suspend fun deleteRingtone(item: RingtoneItem) {
        withContext(Dispatchers.IO) {
            ringtoneDao.delete(item)
            // If it's custom file, delete file as well
            if (item.source == RingtoneSource.CUSTOM) {
                try {
                    val uri = Uri.parse(item.uriString)
                    uri.path?.let { File(it).delete() }
                } catch (e: Exception) {
                    Log.w("RingtoneRepository", "Failed to delete file", e)
                }
            }
        }
    }

    suspend fun recordHistory(historyItem: RotationHistoryItem) {
        withContext(Dispatchers.IO) {
            historyDao.insert(historyItem)
        }
    }

    suspend fun clearHistory() {
        withContext(Dispatchers.IO) {
            historyDao.clearAll()
        }
    }
}
