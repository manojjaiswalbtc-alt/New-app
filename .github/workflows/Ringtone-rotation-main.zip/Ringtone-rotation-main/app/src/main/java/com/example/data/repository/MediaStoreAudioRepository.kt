package com.example.data.repository

import android.content.Context
import com.example.core.RuntimePermissionsHelper
import com.example.data.dao.MediaStoreAudioDao
import com.example.data.model.MediaStoreAudioItem
import com.example.data.model.RingtoneItem
import com.example.data.model.SoundType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * Repository to scan device MediaStore for audio files and expose them
 * as a list of selectable ringtone URIs.
 */
class MediaStoreAudioRepository(
    private val context: Context,
    private val mediaStoreAudioDao: MediaStoreAudioDao
) {
    private val _mediaStoreItems = MutableStateFlow<List<MediaStoreAudioItem>>(emptyList())
    val mediaStoreItems: Flow<List<MediaStoreAudioItem>> = _mediaStoreItems.asStateFlow()

    private val _selectableRingtones = MutableStateFlow<List<RingtoneItem>>(emptyList())
    val selectableRingtones: Flow<List<RingtoneItem>> = _selectableRingtones.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: Flow<Boolean> = _isScanning.asStateFlow()

    /**
     * Determines whether the app has the necessary storage/audio permission.
     */
    fun hasStoragePermission(): Boolean {
        return RuntimePermissionsHelper.hasAudioPermission(context)
    }

    /**
     * Returns the appropriate permission required for media audio on this OS version.
     */
    fun getRequiredStoragePermission(): String {
        return RuntimePermissionsHelper.getAudioPermission()
    }

    /**
     * Scans the device MediaStore on IO dispatcher and updates the exposed Flows.
     */
    suspend fun scanAudioFiles(
        filterType: SoundType? = null,
        minDurationMs: Long = 1000L,
        searchQuery: String? = null
    ): List<MediaStoreAudioItem> {
        return withContext(Dispatchers.IO) {
            _isScanning.value = true
            try {
                val results = mediaStoreAudioDao.queryAudioFiles(
                    filterType = filterType,
                    minDurationMs = minDurationMs,
                    searchQuery = searchQuery
                )
                _mediaStoreItems.value = results
                _selectableRingtones.value = results.map { it.toRingtoneItem(filterType ?: SoundType.RINGTONE) }
                results
            } finally {
                _isScanning.value = false
            }
        }
    }

    /**
     * Looks up an individual item by its MediaStore ID.
     */
    suspend fun getAudioById(id: Long): MediaStoreAudioItem? {
        return withContext(Dispatchers.IO) {
            mediaStoreAudioDao.findAudioById(id)
        }
    }
}
