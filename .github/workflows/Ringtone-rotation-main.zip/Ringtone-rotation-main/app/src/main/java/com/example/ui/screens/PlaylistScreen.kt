package com.example.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.QueueMusic
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.core.PlaybackState
import com.example.data.model.RingtoneItem
import com.example.ui.RotationFeedback
import com.example.ui.components.RingtoneCard
import com.example.ui.components.RotationFeedbackIndicator

@Composable
fun PlaylistScreen(
    playlistItems: List<RingtoneItem>,
    playbackState: PlaybackState,
    currentSystemTitle: String,
    onTogglePlay: (String) -> Unit,
    onTogglePlaylist: (RingtoneItem) -> Unit,
    onApplyNow: (RingtoneItem) -> Unit,
    onDelete: (RingtoneItem) -> Unit,
    onNavigateToLibrary: () -> Unit,
    onRotateNow: () -> Unit = {},
    isRotating: Boolean = false,
    rotationFeedback: RotationFeedback? = null,
    onDismissFeedback: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val enabledCount = playlistItems.count { it.isEnabledInPlaylist }
    val infiniteTransition = rememberInfiniteTransition(label = "playlist_spin")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    Box(modifier = modifier.fillMaxSize()) {
        if (playlistItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Default.QueueMusic,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Playlist is Empty",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Add system ringtones or import custom songs to build your rotation playlist.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onNavigateToLibrary,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("empty_state_browse_library_button")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("Browse Ringtone Library")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp)
            ) {
                // Visual feedback indicator banner
                item {
                    RotationFeedbackIndicator(
                        feedback = rotationFeedback,
                        onDismiss = onDismissFeedback
                    )
                }

                // Quick Rotate Card at top of playlist
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Active Playlist ($enabledCount enabled)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Active tone: $currentSystemTitle",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1
                                )
                            }

                            Button(
                                onClick = onRotateNow,
                                enabled = !isRotating && enabledCount > 0,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                ),
                                modifier = Modifier.testTag("playlist_rotate_now_button")
                            ) {
                                if (isRotating) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Rotating...")
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Autorenew,
                                        contentDescription = "Rotate Now",
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.size(6.dp))
                                    Text("Rotate Now")
                                }
                            }
                        }
                    }
                }

                itemsIndexed(
                    items = playlistItems,
                    key = { _, item -> item.id }
                ) { index, item ->
                    val isPlaying = playbackState.isPlaying && playbackState.currentUriString == item.uriString
                    val isCurrentActive = item.title.equals(currentSystemTitle, ignoreCase = true)

                    RingtoneCard(
                        item = item,
                        isPlaying = isPlaying,
                        onTogglePlay = { onTogglePlay(item.uriString) },
                        isCurrentActive = isCurrentActive,
                        showPlaylistToggle = true,
                        onTogglePlaylist = { onTogglePlaylist(item) },
                        onApplyNow = { onApplyNow(item) },
                        onDelete = { onDelete(item) },
                        orderBadge = index + 1
                    )
                }
            }
        }

        // Floating action button to quickly add from library
        FloatingActionButton(
            onClick = onNavigateToLibrary,
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 96.dp, end = 20.dp)
                .testTag("playlist_add_fab")
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add ringtones from library")
        }
    }
}
