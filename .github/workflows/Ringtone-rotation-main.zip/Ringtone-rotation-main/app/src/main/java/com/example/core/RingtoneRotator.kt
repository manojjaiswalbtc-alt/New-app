package com.example.core

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource
import com.example.data.model.RotationMode
import com.example.data.model.SoundType

data class RotationResult(
    val success: Boolean,
    val rotatedItem: RingtoneItem?,
    val nextIndex: Int,
    val message: String
)

class RingtoneRotator(private val context: Context) {

    companion object {
        private const val TAG = "RingtoneRotator"
    }

    /**
     * Checks if the app has permission to modify system settings.
     */
    fun hasWriteSettingsPermission(): Boolean {
        return RuntimePermissionsHelper.hasWriteSettingsPermission(context)
    }

    /**
     * Opens system settings so the user can grant permission to modify settings.
     */
    fun requestWriteSettingsPermission() {
        RuntimePermissionsHelper.openWriteSettings(context)
    }

    /**
     * Fetches current default system ringtone title and URI.
     */
    fun getCurrentSystemRingtone(soundType: SoundType): Pair<String, Uri?> {
        return try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(context, soundType.ringtoneManagerType)
            if (uri != null) {
                val ringtone = RingtoneManager.getRingtone(context, uri)
                val title = ringtone?.getTitle(context) ?: "Default Sound"
                Pair(title, uri)
            } else {
                Pair("Default Sound", null)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching current system ringtone", e)
            Pair("System Default", null)
        }
    }

    /**
     * Scans and returns all built-in system ringtones for a given SoundType.
     */
    fun querySystemRingtones(soundType: SoundType): List<RingtoneItem> {
        val list = mutableListOf<RingtoneItem>()
        try {
            val manager = RingtoneManager(context).apply {
                setType(soundType.ringtoneManagerType)
            }
            val cursor: Cursor? = manager.cursor
            if (cursor != null) {
                var index = 0
                while (cursor.moveToNext()) {
                    val title = cursor.getString(RingtoneManager.TITLE_COLUMN_INDEX)
                    val uri = manager.getRingtoneUri(cursor.position)
                    if (uri != null && !title.isNullOrBlank()) {
                        list.add(
                            RingtoneItem(
                                title = title,
                                uriString = uri.toString(),
                                source = RingtoneSource.SYSTEM,
                                soundType = soundType,
                                isEnabledInPlaylist = false,
                                orderIndex = index++
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying system ringtones", e)
        }
        return list
    }

    /**
     * Applies a specific URI as the active ringtone for the target sound type.
     */
    fun setRingtone(uri: Uri, soundType: SoundType): Boolean {
        if (!hasWriteSettingsPermission()) {
            return false
        }
        return try {
            RingtoneManager.setActualDefaultRingtoneUri(
                context,
                soundType.ringtoneManagerType,
                uri
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to set default ringtone URI: $uri", e)
            false
        }
    }

    /**
     * Rotates to the next ringtone from a list of items using the selected mode.
     */
    fun rotate(
        ringtoneItems: List<RingtoneItem>,
        currentIndex: Int,
        mode: RotationMode,
        soundType: SoundType
    ): RotationResult {
        if (!hasWriteSettingsPermission()) {
            requestWriteSettingsPermission()
            return RotationResult(
                success = false,
                rotatedItem = null,
                nextIndex = currentIndex,
                message = "Modify System Settings permission required."
            )
        }

        if (ringtoneItems.isEmpty()) {
            return RotationResult(
                success = false,
                rotatedItem = null,
                nextIndex = currentIndex,
                message = "Playlist is empty. Add tones to rotate."
            )
        }

        val targetIndex = when (mode) {
            RotationMode.SEQUENTIAL -> {
                if (currentIndex in ringtoneItems.indices) currentIndex else 0
            }
            RotationMode.SHUFFLE -> {
                if (ringtoneItems.size > 1) {
                    var rand = ringtoneItems.indices.random()
                    if (rand == currentIndex) {
                        rand = (rand + 1) % ringtoneItems.size
                    }
                    rand
                } else {
                    0
                }
            }
        }

        val targetItem = ringtoneItems[targetIndex]
        val targetUri = Uri.parse(targetItem.uriString)

        val applied = setRingtone(targetUri, soundType)
        val nextIndex = (targetIndex + 1) % ringtoneItems.size

        return if (applied) {
            RotationResult(
                success = true,
                rotatedItem = targetItem,
                nextIndex = nextIndex,
                message = "Switched to ${targetItem.title}"
            )
        } else {
            RotationResult(
                success = false,
                rotatedItem = targetItem,
                nextIndex = currentIndex,
                message = "Failed to apply ${targetItem.title}"
            )
        }
    }
}
