package com.example.core

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.SystemClock
import android.util.Log
import com.example.data.model.ScheduleInterval
import com.example.receiver.RotationAlarmReceiver

object RotationScheduler {

    private const val REQUEST_CODE = 9021
    private const val TAG = "RotationScheduler"

    fun updateSchedule(context: Context, interval: ScheduleInterval) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, RotationAlarmReceiver::class.java).apply {
            action = RotationAlarmReceiver.ACTION_ROTATE_ALARM
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val pendingIntent = PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags)

        if (interval == ScheduleInterval.MANUAL) {
            alarmManager.cancel(pendingIntent)
            Log.d(TAG, "Cancelled rotation alarm schedule")
        } else {
            val triggerAt = SystemClock.elapsedRealtime() + interval.intervalMillis
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        triggerAt,
                        pendingIntent
                    )
                } else {
                    alarmManager.setRepeating(
                        AlarmManager.ELAPSED_REALTIME_WAKEUP,
                        triggerAt,
                        interval.intervalMillis,
                        pendingIntent
                    )
                }
                Log.d(TAG, "Scheduled next rotation alarm in ${interval.intervalMillis}ms")
            } catch (e: SecurityException) {
                // If exact alarm permission is missing on Android 12+, fallback to inexact
                alarmManager.set(
                    AlarmManager.ELAPSED_REALTIME_WAKEUP,
                    triggerAt,
                    pendingIntent
                )
                Log.w(TAG, "Fell back to inexact alarm", e)
            }
        }
    }
}
