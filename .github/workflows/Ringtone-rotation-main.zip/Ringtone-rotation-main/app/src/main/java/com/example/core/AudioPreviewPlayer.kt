package com.example.core

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PlaybackState(
    val isPlaying: Boolean = false,
    val currentUriString: String? = null,
    val progress: Float = 0f,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0
)

class AudioPreviewPlayer(private val context: Context) {

    private val playerScope = CoroutineScope(Dispatchers.Main)
    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    fun playOrToggle(uriString: String) {
        val currentState = _playbackState.value
        if (currentState.isPlaying && currentState.currentUriString == uriString) {
            pause()
        } else {
            play(uriString)
        }
    }

    fun play(uriString: String) {
        stop()

        try {
            val uri = Uri.parse(uriString)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(context, uri)
                setOnPreparedListener { mp ->
                    mp.start()
                    val duration = mp.duration.coerceAtLeast(1)
                    _playbackState.value = PlaybackState(
                        isPlaying = true,
                        currentUriString = uriString,
                        progress = 0f,
                        currentPositionMs = 0,
                        durationMs = duration
                    )
                    startProgressTracker()
                }
                setOnCompletionListener {
                    stopProgressTracker()
                    _playbackState.value = PlaybackState(
                        isPlaying = false,
                        currentUriString = uriString,
                        progress = 0f,
                        currentPositionMs = 0,
                        durationMs = it.duration
                    )
                }
                setOnErrorListener { _, what, extra ->
                    Log.e("AudioPreviewPlayer", "MediaPlayer error: what=$what, extra=$extra")
                    stop()
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("AudioPreviewPlayer", "Error playing uri: $uriString", e)
            stop()
        }
    }

    fun pause() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                    _playbackState.value = _playbackState.value.copy(isPlaying = false)
                }
            }
        } catch (e: Exception) {
            Log.e("AudioPreviewPlayer", "Error pausing", e)
        }
        stopProgressTracker()
    }

    fun stop() {
        stopProgressTracker()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            Log.e("AudioPreviewPlayer", "Error stopping player", e)
        }
        mediaPlayer = null
        _playbackState.value = PlaybackState(isPlaying = false, currentUriString = null)
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressJob = playerScope.launch {
            while (isActive) {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        val pos = mp.currentPosition
                        val dur = mp.duration.coerceAtLeast(1)
                        val frac = (pos.toFloat() / dur).coerceIn(0f, 1f)
                        _playbackState.value = _playbackState.value.copy(
                            progress = frac,
                            currentPositionMs = pos,
                            durationMs = dur
                        )
                    }
                }
                delay(80)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        progressJob = null
    }

    fun release() {
        stop()
    }
}
