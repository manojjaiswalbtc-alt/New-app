package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
    darkColorScheme(
        primary = PrimaryIndigoDark,
        onPrimary = Color(0xFF0F172A),
        primaryContainer = PrimaryIndigoContainer,
        onPrimaryContainer = Color(0xFFE0E7FF),
        secondary = CyanAccentDark,
        onSecondary = Color(0xFF083344),
        secondaryContainer = CyanAccentContainer,
        onSecondaryContainer = Color(0xFFCFFAFE),
        tertiary = AmberVibrantDark,
        onTertiary = Color(0xFF451A03),
        tertiaryContainer = AmberVibrantContainer,
        onTertiaryContainer = Color(0xFFFEF3C7),
        background = DarkBackground,
        onBackground = Color(0xFFF1F5F9),
        surface = DarkSurface,
        onSurface = Color(0xFFF1F5F9),
        surfaceVariant = DarkSurfaceVariant,
        onSurfaceVariant = Color(0xFFCBD5E1),
        outline = Color(0xFF64748B),
        error = ErrorRed,
        onError = Color.White
    )

private val LightColorScheme =
    lightColorScheme(
        primary = PrimaryIndigo,
        onPrimary = Color.White,
        primaryContainer = PrimaryIndigoContainerLight,
        onPrimaryContainer = Color(0xFF1E1B4B),
        secondary = CyanAccent,
        onSecondary = Color.White,
        secondaryContainer = CyanAccentContainerLight,
        onSecondaryContainer = Color(0xFF164E63),
        tertiary = AmberVibrant,
        onTertiary = Color.White,
        tertiaryContainer = AmberVibrantContainerLight,
        onTertiaryContainer = Color(0xFF78350F),
        background = LightBackground,
        onBackground = Color(0xFF0F172A),
        surface = LightSurface,
        onSurface = Color(0xFF0F172A),
        surfaceVariant = LightSurfaceVariant,
        onSurfaceVariant = Color(0xFF475569),
        outline = Color(0xFF94A3B8),
        error = ErrorRed,
        onError = Color.White
    )

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our custom cohesive palette for branded look
    content: @Composable () -> Unit,
) {
    val colorScheme =
        when {
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            }
            darkTheme -> DarkColorScheme
            else -> LightColorScheme
        }

    MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
