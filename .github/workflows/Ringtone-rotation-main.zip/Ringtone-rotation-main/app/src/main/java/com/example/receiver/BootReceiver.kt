package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.RingtoneRotatorApplication
import com.example.core.RotationScheduler
import com.example.data.model.ScheduleInterval
import com.example.work.RingtoneWorkScheduler

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED ||
            intent?.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            Log.d("BootReceiver", "Boot completed: restoring rotation schedule")
            val app = context.applicationContext as? RingtoneRotatorApplication ?: return
            val interval = app.preferenceStorage.scheduleInterval.value
            if (interval != ScheduleInterval.MANUAL) {
                RingtoneWorkScheduler.scheduleRotation(context, interval)
                RotationScheduler.updateSchedule(context, interval)
            }
        }
    }
}
