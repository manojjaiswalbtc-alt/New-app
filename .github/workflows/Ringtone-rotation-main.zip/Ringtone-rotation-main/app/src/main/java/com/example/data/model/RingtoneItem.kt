package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ringtones")
data class RingtoneItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val uriString: String,
    val source: RingtoneSource,
    val soundType: SoundType = SoundType.RINGTONE,
    val durationMs: Long = 0L,
    val isEnabledInPlaylist: Boolean = true,
    val orderIndex: Int = 0,
    val addedTimestamp: Long = System.currentTimeMillis()
)
