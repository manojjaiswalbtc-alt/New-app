package com.example.data.prefs

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.RotationMode
import com.example.data.model.ScheduleInterval
import com.example.data.model.SoundType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferenceStorage(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ringtone_rotator_prefs", Context.MODE_PRIVATE)

    private val _currentIndex = MutableStateFlow(prefs.getInt(KEY_CURRENT_INDEX, 0))
    val currentIndex: StateFlow<Int> = _currentIndex.asStateFlow()

    private val _rotationMode = MutableStateFlow(
        RotationMode.entries.getOrNull(prefs.getInt(KEY_ROTATION_MODE, 0)) ?: RotationMode.SEQUENTIAL
    )
    val rotationMode: StateFlow<RotationMode> = _rotationMode.asStateFlow()

    private val _soundType = MutableStateFlow(
        SoundType.entries.getOrNull(prefs.getInt(KEY_SOUND_TYPE, 0)) ?: SoundType.RINGTONE
    )
    val soundType: StateFlow<SoundType> = _soundType.asStateFlow()

    private val _scheduleInterval = MutableStateFlow(
        ScheduleInterval.entries.getOrNull(prefs.getInt(KEY_SCHEDULE_INTERVAL, 0)) ?: ScheduleInterval.MANUAL
    )
    val scheduleInterval: StateFlow<ScheduleInterval> = _scheduleInterval.asStateFlow()

    private val _notificationsEnabled = MutableStateFlow(prefs.getBoolean(KEY_NOTIFICATIONS, true))
    val notificationsEnabled: StateFlow<Boolean> = _notificationsEnabled.asStateFlow()

    private val _lastRotatedTitle = MutableStateFlow(prefs.getString(KEY_LAST_ROTATED_TITLE, "") ?: "")
    val lastRotatedTitle: StateFlow<String> = _lastRotatedTitle.asStateFlow()

    private val _lastRotatedTimestamp = MutableStateFlow(prefs.getLong(KEY_LAST_ROTATED_TIME, 0L))
    val lastRotatedTimestamp: StateFlow<Long> = _lastRotatedTimestamp.asStateFlow()

    fun setCurrentIndex(index: Int) {
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply()
        _currentIndex.value = index
    }

    fun setRotationMode(mode: RotationMode) {
        prefs.edit().putInt(KEY_ROTATION_MODE, mode.ordinal).apply()
        _rotationMode.value = mode
    }

    fun setSoundType(type: SoundType) {
        prefs.edit().putInt(KEY_SOUND_TYPE, type.ordinal).apply()
        _soundType.value = type
    }

    fun setScheduleInterval(interval: ScheduleInterval) {
        prefs.edit().putInt(KEY_SCHEDULE_INTERVAL, interval.ordinal).apply()
        _scheduleInterval.value = interval
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_NOTIFICATIONS, enabled).apply()
        _notificationsEnabled.value = enabled
    }

    fun recordRotation(title: String, timestamp: Long = System.currentTimeMillis()) {
        prefs.edit()
            .putString(KEY_LAST_ROTATED_TITLE, title)
            .putLong(KEY_LAST_ROTATED_TIME, timestamp)
            .apply()
        _lastRotatedTitle.value = title
        _lastRotatedTimestamp.value = timestamp
    }

    companion object {
        private const val KEY_CURRENT_INDEX = "key_current_index"
        private const val KEY_ROTATION_MODE = "key_rotation_mode"
        private const val KEY_SOUND_TYPE = "key_sound_type"
        private const val KEY_SCHEDULE_INTERVAL = "key_schedule_interval"
        private const val KEY_NOTIFICATIONS = "key_notifications"
        private const val KEY_LAST_ROTATED_TITLE = "key_last_rotated_title"
        private const val KEY_LAST_ROTATED_TIME = "key_last_rotated_time"
    }
}
