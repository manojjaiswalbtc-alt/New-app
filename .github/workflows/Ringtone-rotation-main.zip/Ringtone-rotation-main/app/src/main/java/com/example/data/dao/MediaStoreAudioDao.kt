package com.example.data.dao

import android.content.ContentResolver
import android.content.ContentUris
import android.database.Cursor
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.example.data.model.MediaStoreAudioItem
import com.example.data.model.SoundType

/**
 * Data Access Object for querying audio files directly from the Android system MediaStore.
 */
interface MediaStoreAudioDao {
    /**
     * Scans and returns all audio files matching optional criteria.
     * @param filterType Filter specifically for ringtones, notifications, alarms, or null for all.
     * @param minDurationMs Minimum duration in milliseconds to filter out tiny sound effects (default 1000ms).
     * @param searchQuery Optional filter query string for title/artist.
     */
    fun queryAudioFiles(
        filterType: SoundType? = null,
        minDurationMs: Long = 1000L,
        searchQuery: String? = null
    ): List<MediaStoreAudioItem>

    /**
     * Checks if a specific MediaStore URI or ID exists and is accessible.
     */
    fun findAudioById(audioId: Long): MediaStoreAudioItem?
}

class MediaStoreAudioDaoImpl(
    private val contentResolver: ContentResolver
) : MediaStoreAudioDao {

    companion object {
        private const val TAG = "MediaStoreAudioDao"
    }

    override fun queryAudioFiles(
        filterType: SoundType?,
        minDurationMs: Long,
        searchQuery: String?
    ): List<MediaStoreAudioItem> {
        val audioList = mutableListOf<MediaStoreAudioItem>()

        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_MUSIC
        )

        val selectionClauses = mutableListOf<String>()
        val selectionArgs = mutableListOf<String>()

        // Filter out corrupted 0-byte or negative-duration items
        selectionClauses.add("${MediaStore.Audio.Media.SIZE} > 0")
        if (minDurationMs > 0) {
            selectionClauses.add("${MediaStore.Audio.Media.DURATION} >= ?")
            selectionArgs.add(minDurationMs.toString())
        }

        // Apply SoundType flag filter if requested
        when (filterType) {
            SoundType.RINGTONE -> {
                selectionClauses.add("${MediaStore.Audio.Media.IS_RINGTONE} != 0")
            }
            SoundType.NOTIFICATION -> {
                selectionClauses.add("${MediaStore.Audio.Media.IS_NOTIFICATION} != 0")
            }
            SoundType.ALARM -> {
                selectionClauses.add("${MediaStore.Audio.Media.IS_ALARM} != 0")
            }
            null -> {
                // Return all selectable audio
            }
        }

        // Search query filter
        if (!searchQuery.isNullOrBlank()) {
            selectionClauses.add("(${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ?)")
            selectionArgs.add("%$searchQuery%")
            selectionArgs.add("%$searchQuery%")
        }

        val selection = selectionClauses.joinToString(separator = " AND ")
        val sortOrder = "${MediaStore.Audio.Media.TITLE} ASC"

        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(
                collectionUri,
                projection,
                selection,
                selectionArgs.toTypedArray(),
                sortOrder
            )

            cursor?.let { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val isRingtoneCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_RINGTONE)
                val isNotificationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_NOTIFICATION)
                val isAlarmCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_ALARM)
                val isMusicCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_MUSIC)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val title = c.getString(titleCol) ?: "Unknown Track"
                    val artist = c.getString(artistCol)
                    val album = c.getString(albumCol)
                    val duration = c.getLong(durationCol)
                    val size = c.getLong(sizeCol)
                    val isRingtone = c.getInt(isRingtoneCol) != 0
                    val isNotification = c.getInt(isNotificationCol) != 0
                    val isAlarm = c.getInt(isAlarmCol) != 0
                    val isMusic = c.getInt(isMusicCol) != 0

                    val contentUri = ContentUris.withAppendedId(collectionUri, id)

                    audioList.add(
                        MediaStoreAudioItem(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            durationMs = duration,
                            sizeBytes = size,
                            uri = contentUri,
                            isRingtone = isRingtone,
                            isNotification = isNotification,
                            isAlarm = isAlarm,
                            isMusic = isMusic
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            Log.w(TAG, "Missing READ_EXTERNAL_STORAGE or READ_MEDIA_AUDIO permission", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error querying MediaStore audio files", e)
        } finally {
            cursor?.close()
        }

        return audioList
    }

    override fun findAudioById(audioId: Long): MediaStoreAudioItem? {
        val collectionUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM,
            MediaStore.Audio.Media.IS_MUSIC
        )

        val selection = "${MediaStore.Audio.Media._ID} = ?"
        val selectionArgs = arrayOf(audioId.toString())

        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(collectionUri, projection, selection, selectionArgs, null)
            cursor?.let { c ->
                if (c.moveToFirst()) {
                    val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val isRingtoneCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_RINGTONE)
                    val isNotificationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_NOTIFICATION)
                    val isAlarmCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_ALARM)
                    val isMusicCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_MUSIC)

                    val id = c.getLong(idCol)
                    val title = c.getString(titleCol) ?: "Unknown Track"
                    val artist = c.getString(artistCol)
                    val album = c.getString(albumCol)
                    val duration = c.getLong(durationCol)
                    val size = c.getLong(sizeCol)
                    val isRingtone = c.getInt(isRingtoneCol) != 0
                    val isNotification = c.getInt(isNotificationCol) != 0
                    val isAlarm = c.getInt(isAlarmCol) != 0
                    val isMusic = c.getInt(isMusicCol) != 0

                    val contentUri = ContentUris.withAppendedId(collectionUri, id)

                    return MediaStoreAudioItem(
                        id = id,
                        title = title,
                        artist = artist,
                        album = album,
                        durationMs = duration,
                        sizeBytes = size,
                        uri = contentUri,
                        isRingtone = isRingtone,
                        isNotification = isNotification,
                        isAlarm = isAlarm,
                        isMusic = isMusic
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error finding audio by id: $audioId", e)
        } finally {
            cursor?.close()
        }
        return null
    }
}
