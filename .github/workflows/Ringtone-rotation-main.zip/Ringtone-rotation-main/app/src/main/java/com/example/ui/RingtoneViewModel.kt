package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.RingtoneRotatorApplication
import com.example.core.AudioPreviewPlayer
import com.example.core.PlaybackState
import com.example.core.RingtoneRotator
import com.example.core.RotationScheduler
import com.example.data.model.MediaStoreAudioItem
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource
import com.example.data.model.RotationHistoryItem
import com.example.data.model.RotationMode
import com.example.data.model.ScheduleInterval
import com.example.data.model.SoundType
import com.example.data.prefs.PreferenceStorage
import com.example.data.repository.MediaStoreAudioRepository
import com.example.data.repository.RingtoneRepository
import com.example.work.RingtoneWorkScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class NavigationTab(val title: String) {
    ROTATE("Rotate"),
    PLAYLIST("Playlist"),
    LIBRARY("Library"),
    SCHEDULE("Schedule"),
    HISTORY("History")
}

data class RotationFeedback(
    val title: String,
    val soundType: String,
    val isSuccess: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

data class RingtoneRotatorUiState(
    val availableRingtones: List<RingtoneItem> = emptyList(),
    val currentRotationIndex: Int = 0,
    val currentSystemTitle: String = "Loading...",
    val isRotating: Boolean = false,
    val hasPermission: Boolean = false,
    val hasStoragePermission: Boolean = false,
    val rotationMode: RotationMode = RotationMode.SEQUENTIAL,
    val soundType: SoundType = SoundType.RINGTONE,
    val isScanningMediaStore: Boolean = false
)

class RingtoneViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as RingtoneRotatorApplication
    private val repository: RingtoneRepository = app.repository
    private val mediaStoreRepository: MediaStoreAudioRepository = app.mediaStoreAudioRepository
    private val rotator: RingtoneRotator = app.rotator
    private val prefs: PreferenceStorage = app.preferenceStorage
    val audioPlayer: AudioPreviewPlayer = app.audioPreviewPlayer

    val playlistItems: StateFlow<List<RingtoneItem>> = repository.allRingtones
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val enabledPlaylistItems: StateFlow<List<RingtoneItem>> = repository.enabledPlaylistRingtones
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * List of all currently available ringtones that can be rotated through.
     */
    val availableRingtones: StateFlow<List<RingtoneItem>> = enabledPlaylistItems

    val recentHistory: StateFlow<List<RotationHistoryItem>> = repository.recentHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playbackState: StateFlow<PlaybackState> = audioPlayer.playbackState

    val soundType: StateFlow<SoundType> = prefs.soundType
    val rotationMode: StateFlow<RotationMode> = prefs.rotationMode
    val scheduleInterval: StateFlow<ScheduleInterval> = prefs.scheduleInterval

    /**
     * Current rotation index within the playlist.
     */
    val currentIndex: StateFlow<Int> = prefs.currentIndex
    val currentRotationIndex: StateFlow<Int> = prefs.currentIndex

    val notificationsEnabled: StateFlow<Boolean> = prefs.notificationsEnabled

    private val _hasPermission = MutableStateFlow(rotator.hasWriteSettingsPermission())
    val hasPermission: StateFlow<Boolean> = _hasPermission.asStateFlow()

    private val _hasStoragePermission = MutableStateFlow(mediaStoreRepository.hasStoragePermission())
    val hasStoragePermission: StateFlow<Boolean> = _hasStoragePermission.asStateFlow()

    val mediaStoreAudioItems: StateFlow<List<MediaStoreAudioItem>> = mediaStoreRepository.mediaStoreItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectableMediaStoreRingtones: StateFlow<List<RingtoneItem>> = mediaStoreRepository.selectableRingtones
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isScanningMediaStore: StateFlow<Boolean> = mediaStoreRepository.isScanning
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val _currentSystemTitle = MutableStateFlow("Loading...")
    val currentSystemTitle: StateFlow<String> = _currentSystemTitle.asStateFlow()

    private val _currentSystemUri = MutableStateFlow<String?>(null)
    val currentSystemUri: StateFlow<String?> = _currentSystemUri.asStateFlow()

    private val _systemLibraryTones = MutableStateFlow<List<RingtoneItem>>(emptyList())
    val systemLibraryTones: StateFlow<List<RingtoneItem>> = _systemLibraryTones.asStateFlow()

    private val _isLoadingLibrary = MutableStateFlow(false)
    val isLoadingLibrary: StateFlow<Boolean> = _isLoadingLibrary.asStateFlow()

    private val _isRotating = MutableStateFlow(false)
    val isRotating: StateFlow<Boolean> = _isRotating.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _rotationFeedback = MutableStateFlow<RotationFeedback?>(null)
    val rotationFeedback: StateFlow<RotationFeedback?> = _rotationFeedback.asStateFlow()

    fun clearRotationFeedback() {
        _rotationFeedback.value = null
    }

    private val _selectedTab = MutableStateFlow(NavigationTab.ROTATE)
    val selectedTab: StateFlow<NavigationTab> = _selectedTab.asStateFlow()

    init {
        viewModelScope.launch {
            repository.initializeDefaultsIfEmpty()
            refreshPermission()
            refreshStoragePermission()
            refreshCurrentSystemRingtone()
            loadSystemRingtones()
            if (mediaStoreRepository.hasStoragePermission()) {
                scanMediaStoreAudio()
            }
        }
    }

    fun setSelectedTab(tab: NavigationTab) {
        _selectedTab.value = tab
    }

    fun refreshPermission() {
        val granted = rotator.hasWriteSettingsPermission()
        _hasPermission.value = granted
    }

    fun refreshStoragePermission() {
        val granted = mediaStoreRepository.hasStoragePermission()
        _hasStoragePermission.value = granted
        if (granted) {
            scanMediaStoreAudio()
        }
    }

    fun getRequiredStoragePermission(): String {
        return mediaStoreRepository.getRequiredStoragePermission()
    }

    fun scanMediaStoreAudio(searchQuery: String? = null) {
        viewModelScope.launch {
            mediaStoreRepository.scanAudioFiles(searchQuery = searchQuery)
        }
    }

    fun requestPermission() {
        rotator.requestWriteSettingsPermission()
    }

    fun refreshCurrentSystemRingtone() {
        viewModelScope.launch(Dispatchers.IO) {
            val (title, uri) = rotator.getCurrentSystemRingtone(soundType.value)
            _currentSystemTitle.value = title
            _currentSystemUri.value = uri?.toString()
        }
    }

    fun setSoundType(type: SoundType) {
        prefs.setSoundType(type)
        refreshCurrentSystemRingtone()
        loadSystemRingtones()
    }

    fun setRotationMode(mode: RotationMode) {
        prefs.setRotationMode(mode)
    }

    fun setScheduleInterval(interval: ScheduleInterval) {
        prefs.setScheduleInterval(interval)
        RingtoneWorkScheduler.scheduleRotation(app, interval)
        RotationScheduler.updateSchedule(app, interval)
    }

    fun triggerBackgroundRotationWork() {
        RingtoneWorkScheduler.triggerImmediateRotation(app)
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        prefs.setNotificationsEnabled(enabled)
    }

    fun loadSystemRingtones() {
        viewModelScope.launch {
            _isLoadingLibrary.value = true
            val tones = withContext(Dispatchers.IO) {
                rotator.querySystemRingtones(soundType.value)
            }
            _systemLibraryTones.value = tones
            _isLoadingLibrary.value = false
        }
    }

    fun setRotationIndex(index: Int) {
        prefs.setCurrentIndex(index)
    }

    fun rotateToNextRingtone() {
        rotateNow()
    }

    fun rotateNow() {
        if (!_hasPermission.value) {
            requestPermission()
            _statusMessage.value = "Settings permission required to modify ringtones"
            return
        }

        viewModelScope.launch {
            _isRotating.value = true
            val currentPlaylist = repository.getEnabledBySoundType(soundType.value).ifEmpty {
                repository.getEnabledPlaylistSnapshot()
            }
            val result = withContext(Dispatchers.IO) {
                rotator.rotate(
                    ringtoneItems = currentPlaylist,
                    currentIndex = currentIndex.value,
                    mode = rotationMode.value,
                    soundType = soundType.value
                )
            }

            if (result.success && result.rotatedItem != null) {
                prefs.setCurrentIndex(result.nextIndex)
                prefs.recordRotation(result.rotatedItem.title)
                refreshCurrentSystemRingtone()

                repository.recordHistory(
                    RotationHistoryItem(
                        ringtoneTitle = result.rotatedItem.title,
                        ringtoneUri = result.rotatedItem.uriString,
                        soundType = soundType.value.title,
                        triggerSource = "Manual",
                        isSuccessful = true
                    )
                )
                _statusMessage.value = "Rotated to: ${result.rotatedItem.title}"
                _rotationFeedback.value = RotationFeedback(
                    title = result.rotatedItem.title,
                    soundType = soundType.value.title,
                    isSuccess = true
                )
            } else {
                repository.recordHistory(
                    RotationHistoryItem(
                        ringtoneTitle = result.rotatedItem?.title ?: "Unknown",
                        ringtoneUri = result.rotatedItem?.uriString ?: "",
                        soundType = soundType.value.title,
                        triggerSource = "Manual",
                        isSuccessful = false,
                        errorMessage = result.message
                    )
                )
                _statusMessage.value = result.message
                _rotationFeedback.value = RotationFeedback(
                    title = result.message,
                    soundType = soundType.value.title,
                    isSuccess = false
                )
            }
            _isRotating.value = false
        }
    }

    fun applySpecificRingtone(item: RingtoneItem) {
        if (!_hasPermission.value) {
            requestPermission()
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val uri = Uri.parse(item.uriString)
            val success = rotator.setRingtone(uri, soundType.value)
            if (success) {
                prefs.recordRotation(item.title)
                refreshCurrentSystemRingtone()
                repository.recordHistory(
                    RotationHistoryItem(
                        ringtoneTitle = item.title,
                        ringtoneUri = item.uriString,
                        soundType = soundType.value.title,
                        triggerSource = "Direct Apply",
                        isSuccessful = true
                    )
                )
                _statusMessage.value = "Applied: ${item.title}"
            } else {
                _statusMessage.value = "Failed to apply ${item.title}"
            }
        }
    }

    fun togglePlaylistEnabled(item: RingtoneItem) {
        viewModelScope.launch {
            repository.togglePlaylistEnabled(item.id, !item.isEnabledInPlaylist)
        }
    }

    fun addLibraryToneToPlaylist(item: RingtoneItem) {
        viewModelScope.launch {
            repository.addRingtone(item.copy(id = 0, isEnabledInPlaylist = true))
            _statusMessage.value = "Added '${item.title}' to rotation playlist"
        }
    }

    fun addMediaStoreAudioToPlaylist(item: MediaStoreAudioItem) {
        val ringtoneItem = item.toRingtoneItem(soundType.value)
        addLibraryToneToPlaylist(ringtoneItem)
    }

    fun applyMediaStoreAudioNow(item: MediaStoreAudioItem) {
        val ringtoneItem = item.toRingtoneItem(soundType.value)
        applySpecificRingtone(ringtoneItem)
    }

    fun importCustomAudio(uri: Uri) {
        viewModelScope.launch {
            val result = repository.addCustomAudio(uri)
            result.onSuccess {
                _statusMessage.value = "Imported '${it.title}' successfully!"
            }.onFailure {
                _statusMessage.value = "Failed to import: ${it.localizedMessage}"
            }
        }
    }

    fun deleteItem(item: RingtoneItem) {
        viewModelScope.launch {
            repository.deleteRingtone(item)
            _statusMessage.value = "Removed '${item.title}'"
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
            _statusMessage.value = "Rotation history cleared"
        }
    }

    fun togglePreview(uriString: String) {
        audioPlayer.playOrToggle(uriString)
    }

    fun stopPreview() {
        audioPlayer.stop()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
    }
}
