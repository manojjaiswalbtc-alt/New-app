package com.example.receiver

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.RingtoneRotatorApplication
import com.example.core.RotationScheduler
import com.example.data.model.RotationHistoryItem
import com.example.data.model.ScheduleInterval
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RotationAlarmReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_ROTATE_ALARM = "com.example.ACTION_ROTATE_ALARM"
        private const val TAG = "RotationAlarmReceiver"
        private const val NOTIFICATION_ID = 4001
    }

    override fun onReceive(context: Context, intent: Intent?) {
        Log.d(TAG, "onReceive triggered: ${intent?.action}")

        val app = context.applicationContext as? RingtoneRotatorApplication ?: return
        val pendingResult = goAsync()

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val soundType = app.preferenceStorage.soundType.value
                val mode = app.preferenceStorage.rotationMode.value
                val currentIndex = app.preferenceStorage.currentIndex.value
                val interval = app.preferenceStorage.scheduleInterval.value

                val playlist = app.repository.getEnabledBySoundType(soundType)
                if (playlist.isNotEmpty() && app.rotator.hasWriteSettingsPermission()) {
                    val result = app.rotator.rotate(playlist, currentIndex, mode, soundType)
                    if (result.success && result.rotatedItem != null) {
                        app.preferenceStorage.setCurrentIndex(result.nextIndex)
                        app.preferenceStorage.recordRotation(result.rotatedItem.title)

                        app.repository.recordHistory(
                            RotationHistoryItem(
                                ringtoneTitle = result.rotatedItem.title,
                                ringtoneUri = result.rotatedItem.uriString,
                                soundType = soundType.title,
                                triggerSource = "Scheduled",
                                isSuccessful = true
                            )
                        )

                        if (app.preferenceStorage.notificationsEnabled.value) {
                            sendRotationNotification(context, result.rotatedItem.title, soundType.title)
                        }
                    }
                }

                // Reschedule for next tick if interval is not manual
                if (interval != ScheduleInterval.MANUAL) {
                    RotationScheduler.updateSchedule(context, interval)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error executing scheduled rotation", e)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun sendRotationNotification(context: Context, toneTitle: String, typeTitle: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val contentIntent = PendingIntent.getActivity(context, 0, launchIntent, flags)

        val notification = NotificationCompat.Builder(context, RingtoneRotatorApplication.CHANNEL_ID_ROTATION)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Ringtone Rotated")
            .setContentText("Active $typeTitle sound: $toneTitle")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Ringtone Rotator auto-rotated your $typeTitle sound to '$toneTitle'."))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()

        try {
            manager.notify(NOTIFICATION_ID, notification)
        } catch (e: SecurityException) {
            Log.w(TAG, "Notification permission missing", e)
        }
    }
}
