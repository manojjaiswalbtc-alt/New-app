package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.example.core.AudioPreviewPlayer
import com.example.core.RingtoneRotator
import com.example.data.dao.MediaStoreAudioDao
import com.example.data.dao.MediaStoreAudioDaoImpl
import com.example.data.db.AppDatabase
import com.example.data.prefs.PreferenceStorage
import com.example.data.repository.MediaStoreAudioRepository
import com.example.data.repository.RingtoneRepository

class RingtoneRotatorApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var repository: RingtoneRepository
        private set

    lateinit var mediaStoreAudioDao: MediaStoreAudioDao
        private set

    lateinit var mediaStoreAudioRepository: MediaStoreAudioRepository
        private set

    lateinit var preferenceStorage: PreferenceStorage
        private set

    lateinit var rotator: RingtoneRotator
        private set

    lateinit var audioPreviewPlayer: AudioPreviewPlayer
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = AppDatabase.getInstance(this)
        repository = RingtoneRepository(this, database)
        mediaStoreAudioDao = MediaStoreAudioDaoImpl(contentResolver)
        mediaStoreAudioRepository = MediaStoreAudioRepository(this, mediaStoreAudioDao)
        preferenceStorage = PreferenceStorage(this)
        rotator = RingtoneRotator(this)
        audioPreviewPlayer = AudioPreviewPlayer(this)

        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID_ROTATION,
                "Ringtone Rotation Alerts",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifies when system ringtone rotates"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID_ROTATION = "rotation_alerts_channel"
        lateinit var instance: RingtoneRotatorApplication
            private set
    }
}
