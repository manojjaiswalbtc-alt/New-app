package com.example.data.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.RingtoneItem
import com.example.data.model.SoundType
import kotlinx.coroutines.flow.Flow

@Dao
interface RingtoneDao {
    @Query("SELECT * FROM ringtones ORDER BY orderIndex ASC, id ASC")
    fun getAllRingtones(): Flow<List<RingtoneItem>>

    @Query("SELECT * FROM ringtones WHERE isEnabledInPlaylist = 1 ORDER BY orderIndex ASC, id ASC")
    fun getEnabledPlaylistRingtones(): Flow<List<RingtoneItem>>

    @Query("SELECT * FROM ringtones WHERE isEnabledInPlaylist = 1 ORDER BY orderIndex ASC, id ASC")
    suspend fun getEnabledPlaylistSnapshot(): List<RingtoneItem>

    @Query("SELECT * FROM ringtones WHERE soundType = :soundType AND isEnabledInPlaylist = 1 ORDER BY orderIndex ASC, id ASC")
    suspend fun getEnabledBySoundType(soundType: SoundType): List<RingtoneItem>

    @Query("SELECT * FROM ringtones WHERE uriString = :uri LIMIT 1")
    suspend fun findByUri(uri: String): RingtoneItem?

    @Query("SELECT COUNT(*) FROM ringtones")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(ringtone: RingtoneItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(ringtones: List<RingtoneItem>)

    @Update
    suspend fun update(ringtone: RingtoneItem)

    @Query("UPDATE ringtones SET isEnabledInPlaylist = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Delete
    suspend fun delete(ringtone: RingtoneItem)

    @Query("DELETE FROM ringtones WHERE id = :id")
    suspend fun deleteById(id: Long)
}
