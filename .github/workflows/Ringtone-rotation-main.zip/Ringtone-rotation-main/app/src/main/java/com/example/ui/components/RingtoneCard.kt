package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SettingsPhone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.RingtoneItem
import com.example.data.model.RingtoneSource

@Composable
fun RingtoneCard(
    item: RingtoneItem,
    isPlaying: Boolean,
    onTogglePlay: () -> Unit,
    modifier: Modifier = Modifier,
    isCurrentActive: Boolean = false,
    showPlaylistToggle: Boolean = false,
    onTogglePlaylist: ((Boolean) -> Unit)? = null,
    onApplyNow: (() -> Unit)? = null,
    onAddToPlaylist: (() -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    isInPlaylistAlready: Boolean = false,
    orderBadge: Int? = null
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentActive) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isCurrentActive) 3.dp else 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("ringtone_card_${item.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Play/Pause circle button
            Surface(
                shape = CircleShape,
                color = if (isPlaying) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onTogglePlay)
                    .testTag("play_button_${item.id}")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause ${item.title}" else "Play ${item.title}",
                        tint = if (isPlaying) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Ringtone title and metadata
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (orderBadge != null) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(end = 2.dp)
                        ) {
                            Text(
                                text = "#$orderBadge",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Source badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (item.source) {
                            RingtoneSource.SYSTEM -> MaterialTheme.colorScheme.surfaceVariant
                            RingtoneSource.CUSTOM -> MaterialTheme.colorScheme.secondaryContainer
                            RingtoneSource.PRESET -> MaterialTheme.colorScheme.tertiaryContainer
                            RingtoneSource.MEDIASTORE -> MaterialTheme.colorScheme.primaryContainer
                        }
                    ) {
                        Text(
                            text = item.source.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = when (item.source) {
                                RingtoneSource.SYSTEM -> MaterialTheme.colorScheme.onSurfaceVariant
                                RingtoneSource.CUSTOM -> MaterialTheme.colorScheme.onSecondaryContainer
                                RingtoneSource.PRESET -> MaterialTheme.colorScheme.onTertiaryContainer
                                RingtoneSource.MEDIASTORE -> MaterialTheme.colorScheme.onPrimaryContainer
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    if (isCurrentActive) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (isPlaying) {
                        WaveformVisualizer(
                            isPlaying = true,
                            barCount = 4,
                            maxHeight = 14.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action section
            if (showPlaylistToggle && onTogglePlaylist != null) {
                Switch(
                    checked = item.isEnabledInPlaylist,
                    onCheckedChange = onTogglePlaylist,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                        checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    modifier = Modifier.testTag("playlist_switch_${item.id}")
                )
            } else if (onAddToPlaylist != null) {
                if (isInPlaylistAlready) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Already in playlist",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                } else {
                    IconButton(
                        onClick = onAddToPlaylist,
                        modifier = Modifier.testTag("add_to_playlist_${item.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add to playlist",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            if (onApplyNow != null) {
                IconButton(
                    onClick = onApplyNow,
                    modifier = Modifier.testTag("apply_now_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsPhone,
                        contentDescription = "Set as current ringtone",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            if (onDelete != null && item.source == RingtoneSource.CUSTOM) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("delete_item_${item.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete audio file",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}
